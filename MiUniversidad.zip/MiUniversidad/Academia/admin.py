from django.contrib import admin
from Academia.models import *

# Register your models here. Registrar modelos en el archivo para administrrlos en el panel de administracion

admin.site.register(Carrera)
admin.site.register(Estudiante)
admin.site.register(Curso)
admin.site.register(Matricula)



